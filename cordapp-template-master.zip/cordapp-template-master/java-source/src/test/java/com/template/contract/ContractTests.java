package com.template.contract;

public class ContractTests {}