package com.template.contract

class ContractTests